// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "BloodMageGuardAI.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BloodMageGuardAI, "BloodMageGuardAI" );
 